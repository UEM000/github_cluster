from __future__ import annotations
import uuid
import faiss
import os
import gc
import shutil
import threading
from typing import Optional
from collections import OrderedDict
from pyspark.sql import SparkSession
from pyspark import RDD, SparkFiles


class FaissIndexStorage:
    """
    Хранилище FAISS-индексов.

    Упрощённая версия: используется только локальная файловая система
    и механизм распространения файлов Spark (SparkFiles.addFile).

    Это позволяет избежать проблем с подключением к распределённым ФС
    (HDFS / viewfs / WebHDFS) на корпоративных кластерах.
    """
    # DISTRIBUTED_DIRS оставлен для совместимости с внешним кодом
    DISTRIBUTED_DIRS = []
    LOCAL_DIRS = []

    def __init__(
        self,
        sp_s: SparkSession,
        base_dir: Optional[str] = None  # сохранён для совместимости API, не используется
    ):
        self.sp_s = sp_s
        # Флаги для совместимости с внешним кодом
        self._distributed = False
        self._distributed_dir = None

        dir_id = uuid.uuid1().hex[:8]
        self._local_tmp_dir = f"__partition_indexes_{dir_id}"
        os.makedirs(self._local_tmp_dir, exist_ok=True)
        FaissIndexStorage.LOCAL_DIRS.append(self._local_tmp_dir)

    def __getstate__(self):
        state = self.__dict__.copy()
        if "sp_s" in state:
            del state["sp_s"]
        return state

    def save_index(self, index: faiss.Index) -> bytes:
        """
        Сериализует индекс в байты для передачи через Spark.
        Вызывается на экзекьюторах.
        """
        return faiss.serialize_index(index)

    def collect_and_register(self, rdd: RDD) -> list:
        """
        Собирает сериализованные индексы с экзекьюторов,
        сохраняет их во временные файлы и распространяет через SparkFiles.
        Вызывается на драйвере.
        """
        index_refs = []
        for shard in rdd.toLocalIterator():
            partition_indexes = faiss.deserialize_index(shard)
            run_id = uuid.uuid1().hex[:8]
            index_file_name = f"__partition_index_{run_id}.index"
            faiss.write_index(
                partition_indexes,
                f"{self._local_tmp_dir}/{index_file_name}"
            )
            self.sp_s.sparkContext.addFile(f"{self._local_tmp_dir}/{index_file_name}")
            index_refs.append(index_file_name)
            del partition_indexes  # явное освобождение памяти
            gc.collect()
        return index_refs

    def load_index(self, link: str) -> faiss.Index:
        """
        Загружает индекс, распространённый через SparkFiles.
        Вызывается на экзекьюторах.
        """
        return faiss.read_index(SparkFiles.get(link))

    @staticmethod
    def cleanup():
        """Удаляет все временные локальные директории."""
        for dir in FaissIndexStorage.LOCAL_DIRS:
            if os.path.exists(dir):
                try:
                    shutil.rmtree(dir)
                except Exception:
                    pass
        FaissIndexStorage.LOCAL_DIRS = []


class CachingIndex:
    """
    LRU-кэш FAISS-индексов в памяти экзекьютора.
    Предотвращает повторную загрузку одного и того же индекса
    при обработке нескольких партиций.
    """
    def __init__(self, max_index: Optional[int] = None):
        self._max = max_index
        self._cache: OrderedDict = OrderedDict()
        self._lock = threading.Lock()

    def get(
        self,
        reference: str,
        storage: FaissIndexStorage,
        nprobe: int,
    ):
        with self._lock:
            if reference in self._cache:
                self._cache.move_to_end(key=reference)
                return self._cache[reference]
            if self._max and len(self._cache) >= self._max:
                _, evicted = self._cache.popitem(last=False)
                del evicted
                gc.collect()
            tmp_index = storage.load_index(reference)
            inner = faiss.downcast_index(tmp_index)
            if hasattr(inner, "nprobe"):
                inner.nprobe = nprobe
            self._cache[reference] = tmp_index
            return tmp_index