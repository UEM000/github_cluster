from __future__ import annotations

import fsspec
import faiss

from pyspark.sql import SparkSession
from pyspark import RDD
from typing import Optional

class FaissIndexStorage:

    def __init__(
        self,
        sp_s: SparkSession,
        base_dir: Optional[str] = None 
    ):
        self.sp_s = sp_s
        self.base_dir = base_dir
        self._distributed = False
        self._local_tmp_dit = None

    def __getstate__(self):
        state = self.__dict__.copy()
        if "sp_s" in state:
            del state["sp_s"]
        return state

    def save_index(self, index: faiss.Index):
        ...

    def collect_and_register(self, rdd: RDD):
        ...

    def load_index(self, link: str) -> faiss.Index:
        ...

    def cleanup(self):
        ...